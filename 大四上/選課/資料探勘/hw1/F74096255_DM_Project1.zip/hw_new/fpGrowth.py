from collections import Counter
from ast import literal_eval

class preP:
    def __init__(self, li_transSet, minFrq):
        self.rawData = li_transSet
        self.frq = minFrq
        self.itemCtr = Counter(dict())
        self.procData = list(list())
        self.sortedFrqItem = list()
        self.amt_N = len(li_transSet)

    def countItem(self):
        tmp_itemCtr = Counter(dict())
        for transSet in self.rawData:
            for item in transSet:
                tmp_itemCtr[item] += 1

        for key in tmp_itemCtr.keys():
            if tmp_itemCtr[key] >= self.frq:
                self.itemCtr[key] = tmp_itemCtr[key]

    def sortItemCtr(self, rev=True):
        sorted_items = dict(sorted(self.itemCtr.items(), key=lambda item: item[1], reverse=rev))
        self.itemCtr = sorted_items

    def print_itemCtr(self):
        print("\n=====PRINT ITEMCTR=====")
        print(self.itemCtr)
        # for item in self.itemCtr.keys():
        #     print(type(item), item)
        

    def trim_data(self):
        for transSet in self.rawData:
            singleTransSet = list()
            for item in transSet:
                if item in self.itemCtr.keys():
                    singleTransSet.append(item)
            self.procData.append(singleTransSet)

    def set_frqItem(self):
        self.sortedFrqItem = list(self.itemCtr.keys())

    def sort_proc_data(self):
        sorted_proc_data = list(list())
        
        for data in self.procData:
            sorted_proc_data.append(sorted(data, key=lambda x: self.sortedFrqItem.index(x)))
        self.procData = sorted_proc_data

    def print_procData(self):
        print("\n=====PRINT PROCDATA=====")
        
        for procTransSet in self.procData:
            print(procTransSet)


class node:
    def __init__(self, ID, name, frq, parentID):
        self.ID = ID
        self.name = name
        self.frq = frq
        self.parentID = parentID
        self.children = dict()

    # TAR: get treeNode's name
    def get_name(self):
        return self.name
    
    def set_parent_id(self):
        self.parentID = self.ID - self.name
        print("parentID:", self.parentID)
        self.parentID = self.parentID - ","
        print("parentID edited:", self.parentID)

    # TAR: get treeNode's parent
    def get_parent(self):
        return self.parent

    # TAR: add all node's together
    def add_node_2_tree(self, connection):
        for node in connection.values():
            # node.print_node_info()

            # parent is root
            if node.parentID == "" and node.ID not in self.children.keys():
                self.children[node.ID] = node

            # parent is not root
            elif node.parentID != "" and node.ID not in connection[node.parentID].children.keys():
                parentNode = connection[node.parentID]
                parentNode.children[node.ID] = node

    # TAR: add 1
    def count(self):
        self.frq += 1

    # TAR: get treeNode's children list
    def childrenDict(self):
        return self.children

    # TAR: print the whole tree based on rootNode 
    # NOT: see treeNode itself as root
    def print_tree(self, indent=""):
        if self.name == "root":
            print("\n=====PRINT TREE=====")
            print("[root]")
        
        nodeDict = self.childrenDict()

        for element in nodeDict.keys():
            tar_node = nodeDict[element]
            print(f'{indent}  |-- [ {tar_node.name} ], <{tar_node.frq}>')
            tar_node.print_tree(str(indent) + "     ")

    # TAR: print single node's info
    def print_node_info(self):
        
        print("=====-----=====")
        print("ID:", self.ID)
        print("name:", self.name)
        print("frq:", self.frq)
        print("parent:", self.parentID)
        # print("=====-----=====")

class nodeInfo:
    def __init__(self, li_transSet):
        self.li_transSet = li_transSet
        self.nameList = list()
        self.idList = list()
        self.nodeList = list()
        self.connection = dict()
        self.nameNodeDict = dict()
        self.revFrqItem = list()
        self.cpb = dict()
        self.cfpb = dict()

    # TAR: add IDs into <list>nodeInfo.idList
    # LOC: in
    def set_name_and_id_list(self):
        nameList = list()
        idList = list()
        for transSet in self.li_transSet:
            ID = str()
            for element in transSet:
                nameList.append(str(element))
                if transSet.index(element) != 0:
                    ID += ","
                ID += str(element)
                idList.append(ID)
        
        self.nameList = nameList
        self.idList = idList

    def get_nameList(self):
        return self.nameList
    
    def get_idList(self):
        return self.idList

    def set_nodeList(self):
        
        nodeList = list()
        for id, name in zip(self.idList, self.nameList):
            parentID = id[:-len(name)][:-1]
            newNode = node(id, name, 0, parentID)            
            #加入nodeList
            nodeList.append(newNode)

        self.nodeList = nodeList

    def get_nodeList(self):
        return self.nodeList
    
    def print_nodeList(self):
        print("\n=====PRINT NODE INFO NODELIST=====")
        for node in self.nodeList:
            node.print_node_info()

    def set_connection(self):
        for id, node in zip(self.idList, self.nodeList):

            if id not in self.connection.keys():
                self.connection[id] = node
            self.connection[id].frq += 1

    def get_connection(self):
        return self.connection
    
    def set_nameNodeDict(self):
        for node in self.nodeList:
            if node.name not in self.nameNodeDict.keys():
                self.nameNodeDict[node.name] = dict()
            
            if node.ID not in self.nameNodeDict[node.name].keys():
                self.nameNodeDict[node.name][node.ID] = node

    def add_entry(self, node):
        self.connection[node.ID] = node

    def print_nameList(self):
        print("\n=====PRINT NODE INFO NAMELIST")
        print(self.nameList)

    def print_id_list(self):
        print("\n=====PRINT NODE INFO IDLIST=====")
        print(self.idList)

    def print_connection(self):
        print("\n=====PRINT NODE INFO CONNECTION=====", len(self.connection))
        for key in self.connection.keys():
            self.connection[key].print_node_info()

    def print_nameNodeDict(self):
        print("\n=====PRINT NODE INFO NAMENODEDICT=====")
        for name in self.nameNodeDict.keys():
            print(name)
            for id in self.nameNodeDict[name].keys():
                self.nameNodeDict[name][id].print_node_info()

    def set_revFrqItem(self, preP):
        self.revFrqItem = preP.sortedFrqItem
        self.revFrqItem.reverse()

    def print_revFrqItem(self):
        print(self.revFrqItem)

    def get_cpb(self):
        
        # item is int()
        for item in self.revFrqItem[:-1]:
            
            self.cpb[str(item)] = dict()
            nameNodeDict = self.nameNodeDict[str(item)]

            for id in nameNodeDict.keys():

                idNode = nameNodeDict[id]
                strItem = str(item)
                # print("item:", type(str_item), str_item)
                # print("id BEFORE:", type(id), id)
                remove_str_item = "," + strItem
                id = id.replace(remove_str_item, "", 1)
                # print("id AFTER:", type(id), id)
                
                # if str_item != id:
                self.cpb[strItem]['['+id+']'] = idNode.frq

    def print_cpb(self):
        print("\n====PRINT NODE INFO CPB=====")
        
        for item in self.cpb.keys():
            strItem = str(item)
            print(item)
            for id in self.cpb[strItem].keys():

                print("=====---=====")
                print("id:", id)
                # print(type(literal_eval('['+id+']')))
                print(type(literal_eval(id)), literal_eval(id))
                print("frq:", self.cpb[strItem][id])

    def get_cfpb(self):
        
        for item in self.revFrqItem[:-1]:
            strItem = str(item)
            cpbList = self.cpb[strItem].keys()
            new_cpbList = list()
            for cpb in cpbList:
                new_cpbList.append(literal_eval(cpb))
            # print(type(new_cpbList), new_cpbList)
            cfpb = max_common_prefix(new_cpbList)
            # print("cfpb:", cfpb)
            self.cfpb[strItem] = cfpb
        

    def print_cfpb(self):
        print("\n=====PRINT NODE INFO CFPB=====")
        
        # for item in self.cfpb.keys():
        #     print(type(item), item)
        #     print(self.cfpb[item])
        print(self.cfpb)


def max_common_prefix(lists):
    if not lists:
        return []

    min_length = min(len(lst) for lst in lists)
    result = []

    for i in range(min_length):
        current = lists[0][i]
        for lst in lists:
            if lst[i] != current:
                return result
        result.append(current)

    return result


class rules:
    def __init__(self, strItem, cfpbList, preP):
        self.antList = list()
        self.con = [strItem]
        self.sup = round(preP.itemCtr[int(strItem)]/preP.amt_N, 2)
        self.conf = int()
        self.lift = int()

    def print_rules(self):
        print(self.ant) 
        print(self.con)
        print(self.sup)
        print(self.conf)
        print(self.lift)
    
    