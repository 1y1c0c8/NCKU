import itertools
from itertools import combinations
from functools import partial
import ast
import self_made_tool as SMT
from utils import timer, write_file
from collections import Counter
import csv
from fpGrowth import node
import fpGrowth

def generate_partitions(input_list):
    n = len(input_list)
    partitions = []

    for i in range(1, n):
        for subset in combinations(input_list, i):
            complement = [item for item in input_list if item not in subset]
            partitions.append([list(subset), complement])

    return partitions

def get_list_of_transSet(li_input):

    cur_customer = li_input[0][0]
    cur_trans = li_input[0][1]
    cur_trans_list = list()
    ret_li_transSet = list()


    for listTransInfo in li_input:
        
        if listTransInfo[0] == cur_customer:
            # 同消費者同筆交易
            if cur_trans == listTransInfo[1]:
                cur_trans_list.append(int(listTransInfo[2]))
                
            # 同消費者不同筆交易
            else:
                ret_li_transSet.append(cur_trans_list)
                cur_trans_list = list()
                cur_trans_list.append(int(listTransInfo[2]))

                cur_trans = listTransInfo[1]
        
        # 不同消費者 --> 不同筆交易
        else:
            ret_li_transSet.append(cur_trans_list)
            cur_trans_list = list()
            cur_trans_list.append(int(listTransInfo[2]))

            cur_customer = listTransInfo[0]
            cur_trans = listTransInfo[1]
    
    ret_li_transSet.append(cur_trans_list)
    
    return ret_li_transSet

@timer
def get_C1(li_transSet):

    ret_li_all_item = list()

    for transList in li_transSet:
        for item in transList:
            if item not in ret_li_all_item:
                ret_li_all_item.append(item)
    
    return ret_li_all_item

@timer
def get_L1(li_transSet, li_C, amt_N, minSup):

    dict_item_f = Counter()
    minAmt = amt_N * minSup
    ret_li_L = list()
    ret_li_L_f = list()

    for transSet in li_transSet:
        for item in transSet:
            dict_item_f[item] += 1

    for item in dict_item_f.keys():
        if dict_item_f[item] >= minAmt:
            ret_li_L.append(item)
            ret_li_L_f.append(dict_item_f[item])

    return ret_li_L, ret_li_L_f

@timer
def get_C2(li_L1):

    ret_li_L2 = list()
    temp_counter = Counter()

    for itemA in li_L1:
        for itemB in li_L1:
            if itemA != itemB:
                temp_counter[frozenset([itemA, itemB])] += 1
    
    ret_li_L2 = list(temp_counter.keys())

    return ret_li_L2
            
@timer
def get_L(li_transSet, li_C, amt_N, minSup):

    ret_li_L = list()
    ret_li_L_f = list()
    dict_item_counter = Counter()
    minAmt = amt_N * minSup

    for itemset in li_C:
        for transSet in li_transSet:
            if itemset.issubset(set(transSet)):
                dict_item_counter[frozenset(itemset)] += 1
    
    for fset_itemset in dict_item_counter:
        if dict_item_counter[fset_itemset] >= minAmt:
            ret_li_L.append(fset_itemset)
            ret_li_L_f.append(dict_item_counter[fset_itemset])

    return ret_li_L, ret_li_L_f
            
@timer
def get_C(li_L):

    ret_li_C = list()
    temp_counter = Counter()

    for freqItemsetA in li_L:
        for freqItemsetB in li_L:
            if freqItemsetA != freqItemsetB:
                temp_counter[freqItemsetA.union(freqItemsetB)] += 1
    

    ret_li_C = list(temp_counter.keys())

    return ret_li_C

def add_freqItemset(li_L, li_L_sup, dict_freq_itemset):
    for item, sup in zip(li_L, li_L_sup):
        dict_freq_itemset[item] = sup

def add_split(dict_freq_itemset, ctr):

    ctr_end = ctr + 15
    list_temp = list()
    for idx in range(ctr, ctr_end):
        list_temp.append(idx)
    dict_freq_itemset[frozenset(list_temp)] = 1

@timer
def get_rules(dict_data_normalized, amt_N, minConf):

    # keys of dict_data_normalized is frozenset()
    ret_li_rules = list()

    for fset in dict_data_normalized:
        if len(fset) > 1:
            fset_freq = dict_data_normalized[fset]
            ret_possible_ant_N_con = generate_partitions(list(fset))

            for ant_N_con in ret_possible_ant_N_con:
                ant_freq = dict_data_normalized[frozenset(ant_N_con[0])]
                con_freq = dict_data_normalized[frozenset(ant_N_con[1])]
                
                sup = round(fset_freq/amt_N, 2)
                conf = round((fset_freq/ant_freq), 2)
                lift = round(((fset_freq*amt_N)/(ant_freq*con_freq)), 2)
                if ant_freq is not None and con_freq is not None and conf >= minConf:
                    
                    list_str_ant = list()
                    for item in ant_N_con[0]:
                        list_str_ant.append(str(item))

                    list_str_con = list()
                    for item in ant_N_con[1]:
                        list_str_con.append(str(item))

                    ret_li_rules.append(
                        (
                            list_str_ant, 
                            list_str_con, 
                            sup, 
                            conf, 
                            lift
                        )
                    )

    return ret_li_rules

# Target:
#   0) Generate 
#       a) dict_all_data
#           - {fset():["sup", "Qualified"], fset():["sup", "Qualified"]}
#       b) li_freq_itemset
#           - [fset(), fset()...]
#   1) Generate list with column "antecedent", "consequent", "sup", "conf" and "lift".
#   2) Generate list with column "itemset", "sup" and "qualified" <class 'dict'> "itemset":("sup", "bool_qualified")
@timer
def apriori(li_input, sup, conf):
    
    dict_freq_itemset = dict()

    # 先將li_transSet做出來
    li_transSet = get_list_of_transSet(li_input)

    # N
    amt_N = len(li_transSet)

    # 取得C1
    li_C1 = get_C1(li_transSet)

    # 取得L1，list of int
    # L1是Counterr()的.keys()回傳，保證不重複
    li_L1, li_L1_f = get_L1(li_transSet, li_C1, amt_N, sup)
    add_freqItemset(li_L1, li_L1_f, dict_freq_itemset)
    

    # 取得Cn -> Ln -> Cn -> Ln while len(Ln) > 1
    li_C = get_C2(li_L1)

    
    # li_L 是COunter() vaiable的.keys()，保證不重複
    li_L, li_L_f = get_L(li_transSet, li_C, amt_N, sup)
    add_freqItemset(li_L, li_L_f, dict_freq_itemset)
    # ctr = 1
    # add_split(dict_freq_itemset, ctr)
    
    # delta_ctr = 15
    # ctr += delta_ctr
    while(len(li_L) > 1):
        li_C = get_C(li_L)
        # SMT.seqVarCheck(li_C)
        li_L, li_L_f = get_L(li_transSet, li_C, amt_N, sup)
        # SMT.seqVarCheck(li_L)
        add_freqItemset(li_L, li_L_f, dict_freq_itemset)
        # add_split(dict_freq_itemset, ctr)
        # ctr += delta_ctr

    
    # 找出關聯法則
    dict_data_normalized = dict()
    for item in dict_freq_itemset:
        if isinstance(item, int):
            
            fset_item = frozenset([item])
            fset_val = dict_freq_itemset[item]
            dict_data_normalized[fset_item] = fset_val
        else:
            dict_data_normalized[item] = dict_freq_itemset[item]
    
    li_rules =get_rules(dict_data_normalized, amt_N, conf)

    # Generate CSV file
    # with open("Result.csv", "w") as file:
    #     fields = ["antecedent","consequent","support","confidence","lift"]
    #     writer = csv.DictWriter(file, fields)

    #     writer.writeheader()
    #     writer.writerows(li_rules)
    return li_rules

@timer
def custom_apriori(li_transSet, sup, conf):

    dict_freq_itemset = dict()

    # N
    amt_N = len(li_transSet)

    # 取得C1
    li_C1 = get_C1(li_transSet)

    # 取得L1，list of int
    # L1是Counterr()的.keys()回傳，保證不重複
    li_L1, li_L1_sup = get_L1(li_transSet, li_C1, amt_N, sup)
    add_freqItemset(li_L1, li_L1_sup, dict_freq_itemset)
    

    # 取得Cn -> Ln -> Cn -> Ln while len(Ln) > 1
    li_C = get_C2(li_L1)

    
    # li_L 是COunter() vaiable的.keys()，保證不重複
    li_L, li_L_sup = get_L(li_transSet, li_C, amt_N, sup)
    add_freqItemset(li_L, li_L_sup, dict_freq_itemset)
    # ctr = 1
    # add_split(dict_freq_itemset, ctr)
    
    # delta_ctr = 15
    # ctr += delta_ctr
    while(len(li_L) > 1):
        li_C = get_C(li_L)
        # SMT.seqVarCheck(li_C)
        li_L, li_L_sup = get_L(li_transSet, li_C, amt_N, sup)
        # SMT.seqVarCheck(li_L)
        add_freqItemset(li_L, li_L_sup, dict_freq_itemset)
        # add_split(dict_freq_itemset, ctr)
        # ctr += delta_ctr


    dict_data_normalized = dict()
    for item in dict_freq_itemset:
        if isinstance(item, int):
            
            fset_item = frozenset([item])
            fset_val = dict_freq_itemset[item]
            dict_data_normalized[fset_item] = fset_val
        else:
            dict_data_normalized[item] = dict_freq_itemset[item]

    # for key in dict_data_normalized:
    #     print(type(key), key, dict_data_normalized[key])

    
    li_rules =get_rules(dict_data_normalized, amt_N, conf)

    # for li in li_rules:
    #     print(li)

    # Generate CSV file
    with open("tryResult.csv", "w") as file:
        fields = ["antecedent","consequent","support","confidence","lift"]
        writer = csv.DictWriter(file, fields)

        writer.writeheader()
        writer.writerows(li_rules)        


 #    


# ========================================FP-Growth========================================

def get_item_and_sort(li_transSet, amt_N, sup):

    counter_item = Counter()

    for transSet in li_transSet:
        for item in transSet:
            counter_item[item] += 1

    li_del_keys = list()

    for item in counter_item:
        if counter_item[item] < (amt_N*sup):
            li_del_keys.append(item)
        
    for del_key in li_del_keys:
        counter_item.pop(del_key)
        
    sorted_dict_C1 = dict(
        sorted(
            dict(counter_item).items(), 
            key=lambda item: item[1], 
            reverse=True)
        )

    return sorted_dict_C1

def sort_by_ordered_list(list_target, ordered_list):
    return sorted(list_target, key=lambda x: ordered_list.index(x))


def update_li_transSet(li_transSet, dict_C1):

    # SMT.seqVarCheck(li_transSet, name="list of transSet", checkLen=len(li_transSet))

    li_keys = list(dict_C1.keys())
    # SMT.seqVarCheck(li_keys, name="list of dict_C1's keys", checkLen=len(li_keys))
    ret_li_transSet = list()

    for transSet in li_transSet:
        li_filtered_transSet = list()
        for item in transSet:
            if item in li_keys:
                li_filtered_transSet.append(item)
        sorted_filtered_transSet = sort_by_ordered_list(li_filtered_transSet, li_keys)
        ret_li_transSet.append(sorted_filtered_transSet)
        # ret_li_transSet.append(li_filtered_transSet)

    # return ret_li_transSet
    return ret_li_transSet


def fp_growth(li_input, sup):

    # 先將li_transSet做出來
    li_transSet = get_list_of_transSet(li_input)
    SMT.seqVarCheck(li_transSet, checkLen=len(li_transSet), name="list of transSet")
    amt_N = len(li_transSet)

    # 取得items的frequence
    # dict_C1 = {item:frequence}
    dict_C1 = get_item_and_sort(li_transSet, amt_N, sup)
    SMT.dictVarCheck(dict_C1, name="dict of C1", checkLen=len(dict_C1))


    # 更新li_transSet
    li_filtered_li_transSet = update_li_transSet(li_transSet, dict_C1)
    SMT.seqVarCheck(li_filtered_li_transSet, name = "list of filtered transSet", checkLen=len(li_filtered_li_transSet))

    # # 建立FP-Tree
    root = treeNode(name="root", freq=-1, parent=None)
    
    # fpGrowth.addList(root=root, list_added=[1])
    # fpGrowth.addList(root=root, list_added=[2])
    # fpGrowth.addList(root=root, list_added=[3])
    # fpGrowth.addList(root=root, list_added=[1,2])
    # root.printTree(root)



    



