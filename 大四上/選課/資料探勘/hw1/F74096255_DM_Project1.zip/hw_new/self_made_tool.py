# TAR: print length of iterable variable
def iterVarLen(iterVar, name):
    print("--- length of", name, "is", len(iterVar), "---")

# TAR: print part of the iterable variable to check
def seqVarCheck(iterVar, name="TESTING", checkLen=3, dircHead=True):
    print("=====", name, "=====")
    iterVarLen(iterVar, name)
    
    ctr = 1

    if dircHead:
        for item in iterVar[:checkLen]:
            print(ctr, "item in", name, ":\n\t", type(item), item)
            ctr += 1
    else:
        for item in iterVar[-(checkLen):]:
            print(ctr, "item in", name, ":\n\t", type(item), item)
            ctr += 1
    iterVarLen(iterVar, name)

def dictVarCheck(dictVar, name="TESTING", checkLen=3, dircHead=True):
    print("=====", name, "=====")
    iterVarLen(dictVar, name)

    ctr = 0

    if dircHead:
        for item in dictVar:
            if ctr < checkLen:
                print(item, dictVar[item])
                ctr += 1
            else:
                break
    else:
        for item in dictVar[-(checkLen):]:
            if ctr < checkLen:
                print(item, dictVar[item])
                ctr += 1
            else:
                break