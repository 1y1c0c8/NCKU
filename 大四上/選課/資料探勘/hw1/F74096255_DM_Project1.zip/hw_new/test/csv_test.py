import csv
from io import StringIO

# Create a CSV variable as a string
csv_data = StringIO()

# Initialize a CSV writer
csv_writer = csv.writer(csv_data)

# Define header and data
header = ["Name", "Age", "Occupation"]
data = [
    ["Alice", 30, "Engineer"],
    ["Bob", 28, "Designer"],
    ["Charlie", 35, "Developer"],
]

# Write the header to the CSV variable
csv_writer.writerow(header)

# Write the data to the CSV variable
csv_writer.writerows(data)

# Get the CSV data as a string
csv_content = csv_data.getvalue()

# Close the CSV variable
csv_data.close()

# Print the CSV content
print(csv_content)

# Adding a new row
new_row = ["David", 40, "Manager"]
data.append(new_row)
csv_data = StringIO()
csv_writer = csv.writer(csv_data)
csv_writer.writerow(header)
csv_writer.writerows(data)
csv_content = csv_data.getvalue()
csv_data.close()
print("\nCSV content after adding a row:\n", csv_content)

# Removing a specific row (e.g., the second row)
row_to_remove = 2
if 0 <= row_to_remove < len(data):
    del data[row_to_remove - 1]  # Adjust for 0-based index

csv_data = StringIO()
csv_writer = csv.writer(csv_data)
csv_writer.writerow(header)
csv_writer.writerows(data)
csv_content = csv_data.getvalue()
csv_data.close()
print("\nCSV content after removing the second row:\n", csv_content)
