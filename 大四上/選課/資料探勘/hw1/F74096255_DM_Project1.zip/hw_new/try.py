# 輸入一個list variable L
# 

li_transSet = [
  [1,3,4],
  [2,3,5],
  [1,2,3,5],
  [2,5],
  [1],
  [1,2,3,4,5]
]

# C1 = [1,2,3,4,5]
# L1 = [1,2,3,5]
# C2 = [
#   [1,2],
#   [1,3],
#   [1,5],
#   [2,3],
#   [2,5],
#   [3,5]
# ]
# L2 = [
#   [1,3],
#   [2,3],
#   [2,5],
#   [3,5]
# ]
# C2 = [
#   [1,2,3],
#   [1,2,3,5],
#   [1,3,5],
#   [2,3,5]
# ]
# L3 = [
#   [2,3,5]
# ]

# li_input = [
#     [0,0,1],
#     [0,0,2],
#     [0,0,3],
#     [0,0,5],
#     [0,0,6],
#     [0,0,15],
#     [1,1,1],
#     [1,1,3],
#     [1,1,7],
#     [2,2,5],
#     [2,2,9],
#     [3,3,1],
#     [3,3,3],
#     [3,3,4],
#     [3,3,5],
#     [3,3,7],
#     [4,4,1],
#     [4,4,3],
#     [4,4,5],
#     [4,4,7],
#     [4,4,12],
#     [5,5,5],
#     [5,5,10],
#     [6,6,1],
#     [6,6,2],
#     [6,6,3],
#     [6,6,5],
#     [6,6,6],
#     [6,6,16],
#     [7,7,1],
#     [7,7,3],
#     [7,7,4],
#     [8,8,1],
#     [8,8,3],
#     [8,8,5],
#     [8,8,7],
#     [8,8,13],
#     [9,9,1],
#     [9,9,3],
#     [9,9,5],
#     [9,9,7],
#     [9,9,14]
# ]


import algo
from functools import partial
import fpGrowth

# algo.fp_growth(li_input, 0.2)

# order = [1, 3, 5, 7, 2, 6, 4]
# listX = [5,1,4,3,7]

# def convert(item, ordered):
#     return ordered.index(item)


# # idx = partial(convert, ordered=order)
# # listX.sort(key=idx)

# listX.sort(key=partial(convert, ordered=order))
# print(listX)



import fpGrowth as fpg

childrenList = [
    [1,2,5],
    [1,2,6],
    [1,2,7,6],
    [2,4],
    [2,6,8],
    [7]
]

# root = fpg.node(name="root", frq=-1, parent=None)
# infoRec = fpg.nodeInfo()

# # root.addChild(1, infoRec)
# # root.addChild(2, infoRec)

# root.addChildren([1,2,5], infoRec)
# # root.addChildren([1,2,6,7], infoRec)
# root.addChildren([2,4,6], infoRec)

# root.printTree()
# infoRec.printInfo()

# for subList in childrenList:
#   root.addChildrenList(subList, infoRec)



# testList = fpg.nodeInfo()
# root = fpg.node("root", -1, None, [])

# nodeA = fpg.node("3", 1, root, [1,2,3])
# root.add_node_to_tree(nodeA)
# nodeA.set_id(nodeA.get_id_from_list())

# testList.add_ID(123)
# testList.add_entry(nodeA)

# nodeB = fpg.node("5", 1, root, [2,3,5])
# root.add_node_to_tree(nodeB)
# nodeB.set_id(nodeB.get_id_from_list())

# testList.add_ID(235)
# testList.add_entry(nodeB)

# nodeC = fpg.node("9", 1, root, [4,7,9])
# root.add_node_to_tree(nodeC)
# nodeC.set_id(nodeC.get_id_from_list())

# testList.add_ID("479")
# testList.add_entry(nodeC)

# testList.print_id_list()
# testList.print_connection()



li_transSet = [
  [1,3,4],
  [2,3,5],
  [1,2,3,5],
  [2,5],
  [1],
  [1,2,3,4,5]
]

li_mh = [
    [5,11,13,14,15,25],
    [4,5,11,14,15,25],
    [1,5,11,13],
    [3,11,13,21,25],
    [3,5,9,11,15]
]


# li_transSet = [
#   [11,13,24],
#   [22,13,15],
#   [11,22,13,15],
#   [22,15],
#   [11],
#   [11,22,13,24,15]
# ]

# li_transSet = [
#     [1,2,3],
#     [1,2,4]
# ]

# procData = fpg.preP(li_transSet, 3)
data = fpg.preP(li_mh, 3)
data.countItem()
data.sortItemCtr(rev=True)
data.print_itemCtr()
data.trim_data()
data.set_frqItem()
data.sort_proc_data()
# data.print_procData()



info = fpg.nodeInfo(data.procData)
info.set_name_and_id_list()
# info.print_nameList()
# info.print_id_list()

info.set_nodeList()

info.set_connection()
# info.print_connection()
info.set_nameNodeDict()
# info.print_nameList()
# info.print_id_list()
# info.print_nameNodeDict()

root = fpg.node("-1", "root", -1, None)
root.add_node_2_tree(info.connection)
# root.print_tree()

info.set_revFrqItem(data)
# info.print_revFrqItem()

info.get_cpb()
# info.print_cpb()

info.get_cfpb()
info.print_cfpb()

for item in info.cfpb.keys():
	new_rules = fpg.rules(item, info.cfpb[item], data)
	new_rules.print_rules()